(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[0],{

/***/ 127:
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 129:
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 147:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 148:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 149:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 150:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 151:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 152:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 153:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 154:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/asyncToGenerator.js
var asyncToGenerator = __webpack_require__(45);
var asyncToGenerator_default = /*#__PURE__*/__webpack_require__.n(asyncToGenerator);

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__(83);

// EXTERNAL MODULE: ./node_modules/core-js/modules/web.dom-collections.for-each.js
var web_dom_collections_for_each = __webpack_require__(92);

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.concat.js
var es_array_concat = __webpack_require__(101);

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.constructor.js
var es_regexp_constructor = __webpack_require__(109);

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__(115);

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__(121);

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__(122);

// EXTERNAL MODULE: ./node_modules/@babel/runtime/regenerator/index.js
var regenerator = __webpack_require__(18);
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);

// EXTERNAL MODULE: ./node_modules/cloudtables-api/dist/CloudTablesApi.js
var CloudTablesApi = __webpack_require__(82);
var CloudTablesApi_default = /*#__PURE__*/__webpack_require__.n(CloudTablesApi);

// CONCATENATED MODULE: ./src/data/agencies.js
var agenciesList = ["All agencies", "Abbotsford Police", "Abbotsford School Board", "B.C. Assessment", "B.C. Ferries", "B.C. Housing", "B.C. Investment Management Corporation", "B.C. Lottery Corporation", "B.C. Oil and Gas Commission", "B.C. Pavilion Corporation", "B.C. Securities Commission", "B.C. Transit", "B.C. Utilities Commission", "BC Hydro and Power Authority", "Bowen Island", "Burnaby School Board", "Camosun College", "Capilano University", "Chilliwack School Board", "City of Abbotsford", "City of Burnaby", "City of Chilliwack", "City of Coquitlam", "City of Delta", "City of Kamloops", "City of Langley", "City of Maple Ridge", "City of Nelson", "City of New Westminster", "City of Pitt Meadows", "City of Port Coquitlam", "City of Port Moody", "City of Richmond", "City of Surrey", "City of Vancouver", "City of Victoria", "City of White Rock", "College of New Caledonia", "College of the Rockies", "Columbia Basin Trust", "Community Living B.C.", "Coquitlam School Board", "Delta Police", "Delta School Board", "District of Mission", "District of North Vancouver", "District of Saanich", "District of West Vancouver", "Douglas College", "EmilyCarr", "Forestry Innovation Investsment", "Fraser Health", "ICBC", "Interior Health", "Island Health", "Justice Institute of British Columbia", "Kwantlen Polytechnic University", "Langara College", "Langley School Board", "Legal Services Society", "Maple Ridge/Pitt Meadows School Board", "Metro Vancouver", "Metro Vancouver Transit Police", "Mission School Board", "Nelson Police", "New West Police", "New Westminster School Board", "North Island College", "North Vancouver School Board", "Northern Health", "Northern Lights College", "Oak Bay Police", "Okanagan", "PHSA", "Port Moody Police", "Powerex Corporation", "Powertech Labs. Inc.", "Providence Health", "Provincial government", "Richmond School Board", "Royal B.C. Museum", "Royal Roads University", "Saanich Police", "Selkirk College", "Simon Fraser University", "Surrey School Board", "Technical Safety B.C.", "Thompson Rivers University", "Township of Langley", "Transit police", "Translink", "University of British Columbia", "University of Northern British Columbia", "University of the Fraser Valley", "University of Victoria", "Vancouver Coastal Health", "Vancouver Community College", "Vancouver Island University", "Vancouver Police", "Vancouver School Board", "Victoria police", "Village of Anmore", "Village of Belcarra", "Village of Lions Bay", "West Vancouver School Board", "Worksafe B.C."];
/* harmony default export */ var agencies = (agenciesList);
// EXTERNAL MODULE: ./src/css/normalize.css
var normalize = __webpack_require__(147);

// EXTERNAL MODULE: ./src/css/postmedia.css
var postmedia = __webpack_require__(148);

// EXTERNAL MODULE: ./src/css/colors.css
var colors = __webpack_require__(149);

// EXTERNAL MODULE: ./src/css/fonts.css
var fonts = __webpack_require__(150);

// EXTERNAL MODULE: ./src/css/main.css
var main = __webpack_require__(151);

// EXTERNAL MODULE: ./src/css/cloudtable.css
var cloudtable = __webpack_require__(152);

// EXTERNAL MODULE: ./src/css/jquery-ui-autocomplete.css
var jquery_ui_autocomplete = __webpack_require__(153);

// CONCATENATED MODULE: ./src/fonts/Shift-Bold.otf
/* harmony default export */ var Shift_Bold = (__webpack_require__.p + "assets/Shift-Bold.8c454d7e.otf");
// CONCATENATED MODULE: ./src/fonts/Shift-BoldItalic.otf
/* harmony default export */ var Shift_BoldItalic = (__webpack_require__.p + "assets/Shift-BoldItalic.144e2c1f.otf");
// CONCATENATED MODULE: ./src/fonts/BentonSansCond-Regular.otf
/* harmony default export */ var BentonSansCond_Regular = (__webpack_require__.p + "assets/BentonSansCond-Regular.4421f875.otf");
// CONCATENATED MODULE: ./src/fonts/BentonSansCond-RegItalic.otf
/* harmony default export */ var BentonSansCond_RegItalic = (__webpack_require__.p + "assets/BentonSansCond-RegItalic.06edc58b.otf");
// CONCATENATED MODULE: ./src/fonts/BentonSansCond-Bold.otf
/* harmony default export */ var BentonSansCond_Bold = (__webpack_require__.p + "assets/BentonSansCond-Bold.87a66dcd.otf");
// CONCATENATED MODULE: ./src/fonts/BentonSansCond-BoldItalic.otf
/* harmony default export */ var BentonSansCond_BoldItalic = (__webpack_require__.p + "assets/BentonSansCond-BoldItalic.539670da.otf");
// CONCATENATED MODULE: ./src/index.js









 // import'jquery-ui/ui/widgets/autocomplete';

 // CSS







 // FONTS






 // VARS

var appId = 'app';
var tableId = 'cloudtable';
var clientId = 'vsun-pssdb-v10';
var cloudTableIp = '138.197.196.21';
var cloudTableDomain = 'vs-postmedia.cloudtables.me';
var apiKey = '5KhDjJ3plIVSSDRhgm5520Da'; // read-only

var cloudTableId = '61d61386-26fa-11ed-b07d-2b528d595799'; // 93k-row full data
// JS

var init = /*#__PURE__*/function () {
  var _ref = asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee() {
    return regenerator_default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            // create dynamic list of options for agency select tag
            createAgencyComboBox(); // create combobox filter for agencies

            setupAgencyCombobox('#combobox'); // load the unfiltered cloudtable

            loadCloudTable('');

          case 3:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function init() {
    return _ref.apply(this, arguments);
  };
}();

function comboboxChangeHandler(e) {
  // reset container dom element
  $('.cloudtables')[0].textContent = ''; // reload the table with selected agency filtered

  var filterValue = e.target.value === 'all' ? null : e.target.value; // reload table

  loadCloudTable(filterValue);
}

function createAgencyComboBox() {
  var agenciesString = '';
  agencies.forEach(function (d) {
    agenciesString += "<option value='".concat(d, "'>").concat(d, "</option>");
  });
  $('#combobox').append(agenciesString);
}

function loadCloudTable(_x) {
  return _loadCloudTable.apply(this, arguments);
}

function _loadCloudTable() {
  _loadCloudTable = asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee2(agency) {
    var conditionsArray, conditions, api, token, script, app;
    return regenerator_default.a.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            conditionsArray = [{
              id: 'dp-9',
              // find the ID for the agency column in the data page of your cloudtables dataset
              value: agency
            }]; // if the filter has been selected, filter for those options, otherwise show everything (null)

            conditions = agency ? conditionsArray : null; // grab the ct api instance

            api = new CloudTablesApi_default.a(apiKey, {
              clientName: 'pssdb_v10',
              // Client's name - optional
              domain: cloudTableDomain,
              // Your CloudTables host
              // secure: false,              // Disallow (true), or allow (false) self-signed certificates   
              // ssl: false,               // Disable https
              conditions: conditions // Use this to filter table

            }); // build the script tag for the table

            _context2.next = 5;
            return api.token();

          case 5:
            token = _context2.sent;
            script = document.createElement('script');
            script.src = "http://".concat(cloudTableDomain, "/io/loader/").concat(cloudTableId, "/table/d");
            script.setAttribute('data-token', token);
            script.setAttribute('data-insert', tableId);
            script.setAttribute('data-clientId', clientId); // let script_str = await api.dataset('61d61386-26fa-11ed-b07d-2b528d595799').scriptTagAsync();
            // const domParser = new DOMParser();
            // const doc = domParser.parseFromString(script_str, 'text/html');
            // let script_tag = doc.getElementsByTagName('script')
            // console.log(script_tag[0])
            // insert the script tag to load the table

            app = document.getElementById(appId).appendChild(script);

          case 12:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));
  return _loadCloudTable.apply(this, arguments);
}

function setupAgencyCombobox(combobox, defaultText) {
  // change handler
  $(combobox).change(comboboxChangeHandler); // combobox setup

  $(function () {
    $.widget('custom.combobox', {
      _create: function _create() {
        this.wrapper = $('<span>').addClass('custom-combobox').insertAfter(this.element);
        this.element.hide();

        this._createAutocomplete();

        this._createShowAllButton();
      },
      _createAutocomplete: function _createAutocomplete() {
        var selected = this.element.children(':selected'),
            value = selected.val() ? selected.text() : '';
        this.input = $('<input>').appendTo(this.wrapper).val(value).attr('title', '').addClass('custom-combobox-input ui-widget ui-widget-content ui-state-default ui-corner-left').autocomplete({
          delay: 0,
          minLength: 0,
          source: this._source.bind(this)
        }).tooltip({
          classes: {
            'ui-tooltip': 'ui-state-highlight'
          }
        });

        this._on(this.input, {
          autocompleteselect: function autocompleteselect(event, ui) {
            ui.item.option.selected = true;

            this._trigger('select', event, {
              item: ui.item.option
            }); // trigger change event


            $('#combobox').trigger('change');
          },
          autocompletechange: '_removeIfInvalid'
        });
      },
      _createShowAllButton: function _createShowAllButton() {
        var input = this.input,
            wasOpen = false;
        $('<a>').attr('tabIndex', -1).attr('title', 'Show All Items').tooltip().appendTo(this.wrapper).button({
          icons: {
            primary: 'ui-icon-triangle-1-s'
          },
          text: false
        }).removeClass('ui-corner-all').addClass('custom-combobox-toggle ui-corner-right').on('mousedown', function () {
          wasOpen = input.autocomplete('widget').is(':visible');
        }).on('click', function () {
          input.trigger('focus'); // Close if already visible

          if (wasOpen) {
            return;
          } // Pass empty string as value to search for, displaying all results


          input.autocomplete('search', '');
        });
      },
      _source: function _source(request, response) {
        var matcher = new RegExp($.ui.autocomplete.escapeRegex(request.term), 'i');
        response(this.element.children('option').map(function () {
          var text = $(this).text();
          if (this.value && (!request.term || matcher.test(text))) return {
            label: text,
            value: text,
            option: this
          };
        }));
      },
      _removeIfInvalid: function _removeIfInvalid(event, ui) {
        // Selected an item, nothing to do
        if (ui.item) {
          return;
        } // Search for a match (case-insensitive)


        var value = this.input.val(),
            valueLowerCase = value.toLowerCase(),
            valid = false;
        this.element.children('option').each(function () {
          if ($(this).text().toLowerCase() === valueLowerCase) {
            this.selected = valid = true;
            return false;
          }
        }); // Found a match, nothing to do

        if (valid) {
          return;
        } // Remove invalid value


        this.input.val('').attr('title', 'No matches').tooltip('open');
        this.element.val('');

        this._delay(function () {
          this.input.tooltip('close').attr('title', '');
        }, 2500);

        this.input.autocomplete('instance').term = '';
      },
      _destroy: function _destroy() {
        this.wrapper.remove();
        this.element.show();
      }
    }); // execute function

    $(combobox).combobox();
  });
}

init();

/***/ })

},[[154,1,2]]]);